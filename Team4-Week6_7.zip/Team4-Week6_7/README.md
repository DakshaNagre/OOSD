# Team4-Week4
# Introduction
Game maker application can be used to develop games like Breakout Atari, Air Hockey and Space Invader. It is flexible enough to add features to develop other games like Frogger etc..,

# Instructions to run the Project:
## Clone the repository:
``` bash
git clone https://github.iu.edu/P532Fall19/Team4-Week4.git
```
## Import to eclipse:
``` bash
open eclipse -> File -> import -> projects from folder or archive
-> directory -> locate the project -> finish
```
## Download the following JARs:
``` bash
JUnit -> https://mvnrepository.com/artifact/junit/junit/4.11
log4j -> https://mvnrepository.com/artifact/log4j/log4j/1.2.17
Mockito -> https://mvnrepository.com/artifact/org.mockito/mockito-all/1.10.19
```
## Import the downloaded JARs into eclipse build path:
```bash
Right click on project -> Build Path -> Add External Archives ->
choose all the downloaded JARs -> open
```
## Running the application
``` bash
1. Find the main.java from com.gamemaker package
2. Right Click on it and then Run As -> Java Application
```
